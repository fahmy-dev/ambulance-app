import React from "react";

function About() {
  return (
    <div>
      <h1>About</h1>
      <p>
        This is a simple React app that uses the React Router DOM to navigate
        between pages.
      </p>
    </div>
  );
}

export default About;