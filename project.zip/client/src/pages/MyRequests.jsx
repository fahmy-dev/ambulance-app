import React from "react";
function Requests() {
  return (
    <div>
      <h1>Requests</h1>
      <p>
        This is a simple React app that uses the React Router DOM to navigate
        between pages.
      </p>
    </div>
  );
}
export default Requests;